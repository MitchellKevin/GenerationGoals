package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.os.Bundle;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.ActivityControllerBinding;
import com.example.myapplication.databinding.ActivityPresetsBinding;

//import org.jetbrains.annotations.Nullable;

//import com.example.myapplication.databinding.FragmentFirstBinding;

public class Controller extends Fragment {
//    public EditText editTextUserInput;
    public ActivityControllerBinding binding;
//    public String userInput;
//    public String input;
//
//    public String getUserInput(){
//        return userInput;
//    }
//    public void setUserInput(String userInput){
//        this.userInput=userInput;
//        editTextUserInput.setText(input);
//    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    //
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = ActivityControllerBinding.inflate(inflater, container, false);

        binding.terugTeamMaken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Controller.this)
                        .navigate(R.id.action_controller_to_SecondFragment);
            }
        });

        binding.volgendeTeamMaken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Controller.this)
                        .navigate(R.id.action_controller_to_FirstFragment);
//                String input= editTextUserInput.getText().toString();
            }
        });

        return binding.getRoot();
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}