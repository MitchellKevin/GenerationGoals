package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
//
//import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.FragmentFirstBinding;

import io.emqx.mqttConnectie.mqttPublish;

public class firstFragment extends Fragment {
mqttPublish pub=new mqttPublish();

//Doorlinken van de knoppen naar andere pages
    public FragmentFirstBinding binding;


    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);

        binding.buttonStartWedstijd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(firstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_speech);
            }
        });
        binding.teamButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(firstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_team);
            }
        });
        binding.chatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(firstFragment.this)
                        .navigate(R.id.action_FirstFragment_to_chat);
            }
        });

        return binding.getRoot();

    }

//    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//
//        binding.buttonStartWedstijd.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                NavHostFragment.findNavController(firstFragment.this)
//                        .navigate(R.id.action_FirstFragment_to_speech);
//
//            }
//        });
//        binding.buttonPresets.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                NavHostFragment.findNavController(firstFragment.this)
//                        .navigate(R.id.action_FirstFragment_to_presets);
//            }
//        });
//        binding.buttonSpeech.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                NavHostFragment.findNavController(firstFragment.this)
//                        .navigate(R.id.action_FirstFragment_to_speech);
//            }
//        });


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}


//UPDATES