package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.myapplication.databinding.ActivityControllerBinding;
import com.example.myapplication.databinding.ActivityTeamBinding;


public class Team extends Fragment {
    public ActivityTeamBinding binding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = ActivityTeamBinding.inflate(inflater, container, false);

        binding.teamVerlaten.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Team.this)
                        .navigate(R.id.action_team_to_SecondFragment);
            }
        });
        binding.playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Team.this)
                        .navigate(R.id.action_team_to_FirstFragment);
            }
        });
        binding.chatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Team.this)
                        .navigate(R.id.action_team_to_chat);
            }
        });

        return binding.getRoot();
}

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}