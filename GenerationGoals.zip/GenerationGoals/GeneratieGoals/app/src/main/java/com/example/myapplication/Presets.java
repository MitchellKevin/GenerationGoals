package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

//import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.ActivityPresetsBinding;

import io.emqx.mqttConnectie.mqttPublish;

public class Presets extends Fragment {
    mqttPublish pub = new mqttPublish();
    public ActivityPresetsBinding binding;


    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
//Message versturen naar mqtt server als bepaalde knop wordt ingedrukt
        binding = ActivityPresetsBinding.inflate(inflater, container, false);

        binding.terugDeelnemen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Presets.this)
                        .navigate(R.id.action_presets_to_SecondFragment);
            }
        });
        binding.deelnemen1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Presets.this)
                        .navigate(R.id.action_presets_to_FirstFragment);
            }
        });
        binding.deelnemen2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Presets.this)
                        .navigate(R.id.action_presets_to_FirstFragment);
            }
        });
        binding.deelnemen3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Presets.this)
                        .navigate(R.id.action_presets_to_FirstFragment);
            }
        });
        binding.deelnemen4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Presets.this)
                        .navigate(R.id.action_presets_to_FirstFragment);
            }
        });
        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}