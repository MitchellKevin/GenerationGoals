//package com.example.myapplication;
//
//import android.os.Bundle;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
////
////import androidx.annotation.NonNull;
//import androidx.fragment.app.Fragment;
//import androidx.navigation.fragment.NavHostFragment;
//
//import com.example.myapplication.databinding.FragmentFirstBinding;
//
//import io.emqx.mqttConnectie.mqttPublish;
//
//public class customZin extends Fragment {
//    mqttPublish pub=new mqttPublish();
//
//    //Doorlinken van de knoppen naar andere pages
//    public Fragment binding;
//
//
//    @Override
//    public View onCreateView(
//            LayoutInflater inflater, ViewGroup container,
//            Bundle savedInstanceState
//    ) {
//
//        binding = FragmentFirstBinding.inflate(inflater, container, false);
//
//        binding.linkDelen.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                NavHostFragment.findNavController(customZin.this)
//                        .navigate(R.id.action_FirstFragment_to_speech);
//            }
//        });
//
//        return binding.getRoot();
//
//    }
//
//
//    @Override
//    public void onDestroyView() {
//        super.onDestroyView();
//        binding = null;
//    }
//
//}

