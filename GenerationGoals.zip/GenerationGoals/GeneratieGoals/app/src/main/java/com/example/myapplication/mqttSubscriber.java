package com.example.myapplication;

import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class mqttSubscriber extends Speech{
    //    Methoden voor aanroepen van de mqtt
    public void start(){
//Connect met de mqtt server
        String broker = "mqtt://test.mosquitto.org:1883";
        String topic = "GenerationGoals";
        String username = "scholtm19";
        String password = "77KG6u15BuoYx6j5fM9P";
        String clientid = "scholtm19_%";
        int qos = 1;
//Log in op de server
        try {
            MqttClient client = new MqttClient(broker, clientid, new MemoryPersistence());
            // connect options
            MqttConnectOptions options = new MqttConnectOptions();
            options.setUserName(username);
            options.setPassword(password.toCharArray());
            options.setConnectionTimeout(60);
            options.setKeepAliveInterval(60);
            // setup callback
            client.setCallback(new MqttCallback() {

                //Melding voor als de mqtt niet connect aan JAVA file
                public void connectionLost(Throwable cause) {
                    start();
                }

                //  Aangeven dat het bericht is aangekomen van de server
                public void messageArrived(String topic, MqttMessage message) throws Exception {

                    int score1=0;
                    int score2=0;
                    binding.scoreTeam1.setText(score1);
                    binding.scoreTeam2.setText(score2);

                    System.out.println("topic: " + topic);
                    System.out.println("Qos: " + message.getQos());
                    System.out.println("message content: " + new String(message.getPayload()));

//                    Presets
                    if (new String(message.getPayload()).equals("Team1")) {
                        System.out.println("Team 1 heeft gescored");
                        score1++;
                    } if (new String(message.getPayload()).equals("Team2")) {
                        System.out.println("Team 2 heeft gescored");
                        score2++;
                    }
                }


                public void deliveryComplete(IMqttDeliveryToken token) {
                    System.out.println("deliveryComplete---------" + token.isComplete());
                }

            });
            client.connect(options);
            client.subscribe(topic, qos);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}

