package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplication.databinding.ActivitySpeechBinding;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class Speech extends Fragment {
    private MqttClient mqttClient;
    public ActivitySpeechBinding binding;

    private String clientId = "scholtm19_" + System.currentTimeMillis();

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = ActivitySpeechBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupMqttClient();

        binding.stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(Speech.this)
                        .navigate(R.id.action_speech_to_FirstFragment);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mqttClient != null) {
            try {
                mqttClient.disconnect();
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }
        binding = null;
    }

    private void setupMqttClient() {
        String broker = "tcp://test.mosquitto.org:1883";
        String topic = "GenerationGoals";
        int qos = 1;

        try {
            mqttClient = new MqttClient(broker, clientId, new MemoryPersistence());
            MqttConnectOptions options = new MqttConnectOptions();
            options.setConnectionTimeout(60);
            options.setKeepAliveInterval(60);

            mqttClient.setCallback(new MqttCallback() {
                private int score1 = 0;
                private int score2 = 0;

                @Override
                public void connectionLost(Throwable cause) {
                    // Handle connection lost
                    setupMqttClient();
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    String payload = new String(message.getPayload());
                    getActivity().runOnUiThread(() -> {
                        if (payload.equals("Team1")) {
                            score1++;
                        } else if (payload.equals("Team2")) {
                            score2++;
                        }
                        binding.scoreTeam1.setText(String.valueOf(score1));
                        binding.scoreTeam2.setText(String.valueOf(score2));
                    });
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    // Handle delivery complete
                }
            });

            mqttClient.connect(options);
            mqttClient.subscribe(topic, qos);

        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}
