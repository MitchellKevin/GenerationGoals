# PAD herkansing

## Collaborate with your team
Team members: Mitchell Scholte(scholtm19)

# Editing this README

When you're ready to make this README your own, just edit this file and use the handy template below (or feel free to structure it however you want - this is just a starting point!). Thank you to [makeareadme.com](https://www.makeareadme.com/) for this template.

## Name
Project Agile Development

## Description
In dit project zorg ik ervoor dat je NAO robot kan besturen met een android app door gebruik te maken van de communcatieprotocool MQTT.

## Installation
Gebruik de SDK: Project SDK 14, 
                java-naoqi-sdk-2.5.6.5-win32-vs2013.jar

Als je connectie wil maken via kabel moet je het IP address veranderen in de ipAddress class. 
Je komt achter het IP address door de volgende stappen te volgen:
1. Ga naar 'Netwerk en internet' in je instellingen
2. Ga naar 'Geavanceerde netwerkinstellingen
3. Ga naar 'Meer opties voor netwerkadapter
4. Druk op rechter muis knop boven 'Wi-Fi' ga naar eigenschappen
5. Ga naar het kopje delen en schakkel internetverbinding delen aan en zet hem op ethernet
6. Reset de NAO robot
7. Ga naar je cmd en typ de volgende commando in 'arp -a' hierdoor zie je al je ip addressen. Éen van de ip adressen is van de NAO robot.


## Support
Email: mitchell.scholte@hva.nl


## License
Hogeschool van Amsterdam

